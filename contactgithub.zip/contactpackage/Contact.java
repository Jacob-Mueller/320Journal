package contactpackage;

public class Contact {
	String ID;
	String firstName;
	String lastName;
	String address;
	String phone;
	
	public Contact(String ID, String firstName, String lastName, String phone, String address) throws Exception {
		if (ID.length() > 10) {
			throw new Exception("ID cannot be longer than 10 characters.");
		}
		if (ID.isEmpty()) {
			throw new Exception("ID cannot be left blank.");
		}
		if (firstName.length() > 10) {
			throw new Exception("First Name cannot be longer than 10 characters.");
		}
		if (firstName.isEmpty()) {
			throw new Exception("First Name cannot be left blank.");
		}
		if (lastName.length() > 10) {
			throw new Exception("Last Name cannot be longer than 10 characters.");
		}
		if (lastName.isEmpty()) {
			throw new Exception("Last Name cannot be left blank.");
		}
		if (phone.length() != 10) {
			throw new Exception("Phone must be 10 characters.");
		}
		if (address.length() > 30) {
			throw new Exception("Address cannot be longer than 30 characters.");
		}
		if (address.isEmpty()) {
			throw new Exception("Address cannot be left blank.");
		}
		
		this.ID = ID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.phone = phone;
	}
	
	public String getID() {
	    return this.ID;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) throws Exception {
		if (firstName.length() > 10) {
			throw new Exception("First Name cannot be longer than 10 characters.");
	    }
		
	    if (firstName.isEmpty()) {
	    	throw new Exception("First Name cannot be left blank.");
	    }
	    this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) throws Exception {
		if (lastName.length() > 10) {
			throw new Exception("Last Name cannot be longer than 10 characters.");
	    }
		
	    if (lastName.isEmpty()) {
	    	throw new Exception("Last Name cannot be left blank.");
	    }
	    this.lastName = lastName;
	}

	public String getPhone() {
		return this.phone;
	}

	public void setPhone(String phone) throws Exception {
		if (phone.length() != 10) {
			throw new Exception("Phone must be 10 characters.");
		}
	    this.phone = phone;
	}

	public String getAddress() {
		return this.address;
	}

	public void setAddress(String address) throws Exception {
		
		if (address.length() > 30) {
			throw new Exception("Address cannot be longer than 30 characters.");
	    }
	    if (address.isEmpty()) {
	    	throw new Exception("Address cannot be left blank.");
	    }
	    this.address = address;
	}
}