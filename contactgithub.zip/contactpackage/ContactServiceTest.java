package contactpackage;

import org.junit.BeforeClass;
import org.junit.Test;
import contactpackage.ContactService;
import junit.framework.TestCase;

public class ContactServiceTest {

  ContactService svc;

  @Test
  public void testAddContact() throws Exception {
	  svc = new ContactService();
	  svc.addContact("John", "Doe", "5555555555", "123 Main St.");
  }
  
  @BeforeClass
  void setUp() throws Exception {
	  svc = new ContactService();
	  svc.addContact("John", "Doe", "5555555555", "123 Main St.");
  }
  @Test
  public void testDeleteContact() throws Exception {
	  String johnID;
	  svc = new ContactService();
	  johnID = svc.getByFirstName("John");
	  svc.deleteContact(johnID);
  }

  @Test
  public void testUpdateContact() throws Exception {
	  String id;
	  svc = new ContactService();
	  svc.addContact("Jane", "Doe", "1234567890", "321 Main St.");
	  id = svc.getByFirstName("Jane");
	  svc.updateContact(id, "Jane", "Doe", "1234567890", "321 Main St.");
  }
}