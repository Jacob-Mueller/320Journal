package contactpackage;

import org.junit.Test;
import org.junit.jupiter.api.Assertions;

import contactpackage.Contact;
import junit.framework.TestCase;
import org.junit.jupiter.api.Assertions.*;

public class ContactTest extends TestCase {
	Contact contact;


	@Test
	public void testAddContact() throws Exception {
		try {
			contact = new Contact("1", "John", "Doe", "5555555555", "123 Main St.");
	    } catch (Exception e) {
	    }
	}
	
	@Test
	void testContactID() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "John", "Doe", "5555555555", "123 Main St.");
		});
	}
	
	@Test
	void testContactIDLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678901", "John", "Doe", "5555555555", "123 Main St.");
		});
	}
	
	@Test
	void testContactNameLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "John5678901", "Doe", "5555555555", "123 Main St.");
		});
	}
	
	@Test
	void testContactNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", null, "Doe", "5555555555", "123 Main St.");
		});
	}
	
	@Test
	void testContactLastNameNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "john", null, "5555555555", "123 Main St.");
		});
	}
	
	@Test
	void testContactNameLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("123", "john", "Doe45678901", "5555555555", "123 Main St.");
		});
	}
}